# The brain tumor detector project
This is an on-going project and gets updated according to the video playlist by MLDawn at my [the step by step playlist at MLDawn](https://www.youtube.com/watch?v=CiW8gS7kqOY&list=PL5foUFuneQnratPPuucpVxWl4RlqueP1u) and the link to the dataset on Kaggle is in [here](https://www.kaggle.com/navoneel/brain-mri-images-for-brain-tumor-detection)
