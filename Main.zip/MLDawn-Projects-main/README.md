# MLDawn-Projects
This repository contains projects defined in the blog posts by www.mldawn.com. The codes are heavily commented so one should not have difficulties understanding them. In the from_scratch folder, you will find algorithms coded from scratch in pure Python. More folders will be added, where libraries are used such as Pytorch, to solve interesting problems.
